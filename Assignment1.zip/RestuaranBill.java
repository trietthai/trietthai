
/*Restaurant Bill
Write a program that computes tax and tip on a restaurant bill.
Ask user to input the bill amount and the tip percentage he/she wants 
to give to the waiter. The tax should be 10% of the meal cost, 
and must be set as a constant in your code. The tip should be calculated
after adding tax. Display the meal cost, tax amount, 
tip amount, and total bill on the screen.
Name your project RestaurantBill.java.*/
import java.util.Scanner;
/**
*
* @author TRIET THAI
*/

public class RestuaranBill {
	public static void main(String[] args) {
		double billAmount, taxAmount, taxPercentage, tipAmount=0, totalBill, mealCost=0;
		double tipPercentage; 
		Scanner keyboard = new Scanner(System.in); // create scanner object to read input
	    System.out.println("Please enter billAmount: "); // to enter billAmount
	    billAmount= keyboard.nextDouble();
	    //System.out.println("Please enter taxAmount: "); // to enter billAmount
	    //taxPercentage =keyboard.nextDouble();
	    System.out.println("Please enter tipPercentage: "); // to enter billAmount
	    tipPercentage =keyboard.nextDouble();
	   
	    taxAmount= (billAmount* 10)/100;
	    mealCost = billAmount + tipAmount;
	    tipAmount= (mealCost + taxAmount)*tipPercentage/100;
		totalBill=mealCost +tipAmount;
		//Display the bill
		System.out.println("The meal cost: " + mealCost);
		System.out.println("The tax amount: " + taxAmount);
		System.out.println("The tip amount: " + tipAmount);
		System.out.println("The total bill: " + totalBill);
		
	}

}
