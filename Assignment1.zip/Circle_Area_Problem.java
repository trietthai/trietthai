  // ********* Problem 2: Circle Area Problem ***********
    
    // TODO Implement the following step-by-step plan
    
    // 1. Declare double constant PI to hold 3.14
    // 2. Declare a double variable to store radius
    // 3. Declare a double variable to store area   
    // 4. Prompt the user to enter radius. 
    // 5. Input radius and store it in variable
    // 6. Calculate circle area. Find the formula on the web if you don't remember it
    // 7. Output the circle's radius and area values in user-friendly fashion
    
    // ********* End of Circle Area Problem code area ***********

import java.util.Scanner;
/**
*
* @author TRIET THAI
*/
public class Circle_Area_Problem {
	public static void main(String[] args) {
		
		double PI =3.14; // Declare double constant PI to hold 3.14
		double radius, area; // Declare a double variable to store radius & area
		Scanner keyboard = new Scanner(System.in); // create scanner object to read input
	    System.out.println("Please enter radius value: "); // to enter radius
	    radius = keyboard.nextDouble(); // input radius value
	    area = Math.PI *radius*radius;  //Calculate circle area
	    //Output the circle's radius and area values
		System.out.print("the circle's radius and area values "+  radius + " and "+ area);
	
	}

}
