import java.util.Scanner;
/**
*
* @author TRIET THAI
*/

/*Interest Earned
Assuming there are no deposits other than the original investment, the balance in a
savings account after one year might be calculated as:
Amount = Principal * (1 + Rate/T)T
Principal is the balance in the savings account, Rate is the interest rate (in decimal form �
0.0425 for 4.25%), and T is the number of times the interest is compounded during a year
(T is 4 if the interest is compounded quarterly).
Write a program that asks for the principal, the interest rate, and the number of times the
interest is compounded then calculates the interest amount and echo-prints all the 
information as well as result of calculations into the screen. See a sample output below.
Interest rate: 4.25%
Times compounded: 12
Principal: $1000.00
Interest: $43.34
Amount in Savings: $1043.34
Name your project InterestEarned.java.

*/
public class InterestEarned {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double Amount,Principal,interest, rate, amountSaving;
		int T,Tcomp;
		// create scanner object to read input
	    Scanner keyboard = new Scanner(System.in); 
	    System.out.print("Enter principal: ");
	    Principal = keyboard.nextDouble();
	    System.out.print("Ener interest rare: ");
	    rate = keyboard.nextDouble();
	    System.out.print("Enter T: ");
	    T = keyboard.nextInt();
	    Tcomp = T*3;
	    amountSaving = Principal * Math.pow((1+rate/T),T);
	    interest = amountSaving - Principal;
	    System.out.println("Interest rate: " + rate);
	    System.out.println("Times compounded: " + Tcomp );
	    System.out.println("Principal: " + Principal);
	    System.out.println("Interest:" + interest);
	    System.out.println("Amount in Saving: " + amountSaving );
		
		
	    

	}

}
