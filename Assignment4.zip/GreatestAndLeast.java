/**
 *
 * @author TRIET THAI
 */


/** 
The Greatest and the Least of These
Write a program with a loop that lets the user enter a series of positive integers. The user
should enter -99 to signal the end of the series. After all the numbers have been entered,
the program should display the largest and the smallest numbers entered.
*/


import java.util.*;
public class GreatestAndLeast
{
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
       int count = 0, num = 0, max = 0, min = 0; // to hold integer
       String str; // to hold input string 

       //Input menu
       System.out.println("Ennter a series of positive integers.");
       System.out.println("Enter -99 to signal end of the series.");
 
       // Scanner input
       Scanner keyboard = new Scanner(System.in);
       
       while (true) // using while loop for all true input
       {
           System.out.println("Enter an integer number or -99: ");
           str = keyboard.nextLine(); // get string type for the input number
           num = Integer.parseInt(str);  // convert number from integer to string type.           
	        
           if (num == -99) 
           {
               if (count == 0) 
               {
               	System.out.println("\nNo numbers were entered");
               } 
               else 
               {
               	// print the results.
                   System.out.println("\nThe largest number: " + max + "\nThe smallest number: " + min);
               }
               System.exit(0);// exit 
           }
           // Compare numbers
           if (count == 0) 
           {
               max = num;
               min = num;
           } 
           else if (num > max) 
           {
               max = num;
           } 
           else if (num < min)
           {
               min = num;
           }
           count++;
      } // end of validation loop
   }

}

