
/**
 *
 * @author TRIET THAI
 */

/**File with Random Numbers
Write a program that generates 100 random integers in a given range and stores the
integers in a file with a given name. When numbers are written into the file each integer
is placed on a separate line.
*/


import java.io.*;
import java.io.PrintWriter;
import java.util.Random;
import java.util.*;
 


public class  RandomsInFile
{

   public static void main(String[] args)
   {
      String str1,str2;   // To hold input string 
      double min = 0, max =0;   // To hold integer
      double num = 0; // To hold double
      int randNum;
      Random rand = new Random(); //setting up random nums
      // create a Scanner object to read input
      Scanner keyboard = new Scanner(System.in);
      // ask user enter file name where the numbers will be written to.
      System.out.println("Enter a file name where the numbers will be written to: ");
      String fileName = keyboard.nextLine();
      File filename = new File(fileName);
      boolean again = true;
      while(again) // input validation loop
      {
    	  System.out.println("\nEnter a small positive integer: ");
    	  str1 = keyboard.nextLine(); // get a string containing a double number
    	  str1 = str1.trim(); // 
    	  System.out.println("\nEnter a large positive integer: ");
    	  str2 = keyboard.nextLine(); // get a string containing a double number
    	  str2 = str2.trim(); //
    	  try    
    	  {
    		// trying to convert integer to string, expecting exceptions
    		  min  = Integer.parseInt(str1);   
    		  max  = Integer.parseInt(str2);
    		  
    		  again =  false; // stop input validation loop
    		 
    	  }
    	  catch (Exception e) // handle the exception
    	  {
    		  System.out.println("INPUT ERROR: Enter an integer number!"); 
    		  System.out.println(e.getMessage());
    	  }
      } // end of validation loop
      if(min>max)
      { 
    	  //swaping numbers to make sure that
    	  //the numbers of the range in correct order.
    	  //lower limit is smaller than upper limit
    	  num = max;
    	  max = min;
    	  min =num;
      }
      //File filename = new File(fileName);
      //File file = new File(fileName);0
      if(filename.exists())
      {
    	  System.out.print("The file name : "+ fileName);
      }
      try
      {
    	  //generates 100 random integers in a given range and stores the
    	  //integers in a file with a given name 
    	  PrintWriter outputFile = new PrintWriter(filename);
    	  for(int i = 1; i <100; i++)
    	  {
    		  randNum = (int)(rand.nextInt((int)((max - min )+1)) + min);
    		  outputFile.println(randNum);
    	  }
    	  outputFile.close();// close output file
    	  //data wrote to the file
    	  System.out.println("\n Numbers are written into the file: "+ fileName );
      
      }
      catch(IOException e)
      {
    	  System.out.println("Cannot open the file" +e.getMessage());
      }
      try // trying to exceptions
      {
    	  again =  false; // stop input validation loop
    	  // continue with the program
      }
      catch (Exception e) // handle the exception below
      {
		   System.out.println("INPUT ERROR!"+ e.getMessage()); 

      }
   } // end of validation loop     
}

